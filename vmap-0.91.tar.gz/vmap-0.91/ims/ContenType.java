/*Vmap - A Program for creating and viewing Mindmaps
/*$Id: ContenType.java,v 1.1 2005/03/05 16:09:10 veghead Exp $ */

package ims;

public class ContenType {

    private String referential;

    public void ContenType() {
        System.out.println("CT created");
    }

}
   
